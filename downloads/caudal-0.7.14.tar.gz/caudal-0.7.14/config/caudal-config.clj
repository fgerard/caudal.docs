(ns caudal.config.basic
  (:require
   [mx.interware.caudal.io.rest-server :refer :all]
   [mx.interware.caudal.streams.common :refer :all]
   [mx.interware.caudal.streams.stateful :refer :all]
   [mx.interware.caudal.streams.stateless :refer :all]))

(deflistener tcp [{:type 'mx.interware.caudal.io.tcp-server
                   :parameters {:port 9900
                   :idle-period 60}}])

(deflistener tailer [{:type 'mx.interware.caudal.io.tailer-server
                      :parameters {:parser      read-string
                                   :inputs      {:directory "./logdir/"
                                                 :wildcard "log.txt"
                                                 }
                                   :delta       100
                                   :from-end    true
                                   :reopen      true
                                   :buffer-size (* 1024 50)}}])

(defsink example 1
  (counter [:state-counter :event-counter]
           (smap [#(let [now (java.util.Date.)] 
                     (-> % 
                         (assoc :millis (-> now .getTime))
                         (assoc :date now)))]
                 (->INFO [:all]))))

(config-view [example] {:doughnut {:state-counter {:value-fn :n :tooltip [:n]}}})

(wire [tcp tailer] [example])

(web
 {:http-port 9901
  :publish-sinks [example]})
